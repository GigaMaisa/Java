package org.example.task3;

import java.util.*;
import java.util.stream.Collectors;

public class TaskManagementSystem {
    private final List<Task> tasks = new ArrayList<>();
    private final TaskComparator taskComparator = new TaskComparator();

    public void addTask(Task task) {
        tasks.add(task);
    }

    public List<Task> getTaskListOrderedByPriority() {
        return tasks.stream()
                .sorted(taskComparator)
                .collect(Collectors.toList());
    }

    public void searchForTask(int id) {
        for (Task task : tasks) {
            if (task.getId() == id) {
                System.out.println(task);
            }
        }
    }

    public void deleteTask(int id) {
        tasks.removeIf(task -> task.getId() == id);
    }

    public List<List<Task>> getListOfListsWithSamePriority() {
        Map<Integer, List<Task>> groupedTasks = tasks.stream()
                .collect(Collectors.groupingBy(Task::getPriority));

        return new ArrayList<>(groupedTasks.values());
    }

}
