package org.example.task3;

public class Main {
    public static void main(String[] args) {
        TaskManagementSystem taskManagementSystem = new TaskManagementSystem();

        taskManagementSystem.addTask(new Task(123, "Nigga", 3));
        taskManagementSystem.addTask(new Task(143, "Nigga11", 5));
        taskManagementSystem.addTask(new Task(24, "awfe", 2));
        taskManagementSystem.addTask(new Task(11, "bruh", 4));
        taskManagementSystem.addTask(new Task(12, "bruh", 2));

        taskManagementSystem.deleteTask(11);
        taskManagementSystem.searchForTask(24);

        System.out.println(taskManagementSystem.getListOfListsWithSamePriority());
        System.out.println(taskManagementSystem.getTaskListOrderedByPriority().toString());
    }
}
