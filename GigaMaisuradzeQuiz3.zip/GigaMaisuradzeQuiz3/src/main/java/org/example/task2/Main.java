package org.example.task2;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        TaskTwo secondTask = new TaskTwo();

        secondTask.addStudent(new Student("Gigla", "Berbichashvili", 1, Arrays.asList(80, 90, 95)));
        secondTask.addStudent(new Student("Jano", "Xvichia", 2, Arrays.asList(85, 88, 92)));
        secondTask.addStudent(new Student("Bob", "Johnson", 3, Arrays.asList(90, 85, 87)));
        secondTask.addStudent(new Student("Nigga", "Mavaniani", 4, Arrays.asList(75, 80, 82)));

        List<Student> topStudents = secondTask.getTopStudents();
        System.out.println("Top 3 Students:");
        for (Student student : topStudents) {
            System.out.println(student.getName() + " " + student.getLastName());
        }
    }
}
