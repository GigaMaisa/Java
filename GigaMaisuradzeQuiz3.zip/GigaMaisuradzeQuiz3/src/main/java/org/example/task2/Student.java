package org.example.task2;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class Student {
    private String name;
    private String lastName;
    private int groupNumber;
    private List<Integer> gradesList;
}
