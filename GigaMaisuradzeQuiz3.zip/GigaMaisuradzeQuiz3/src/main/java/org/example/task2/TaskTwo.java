package org.example.task2;

import java.util.*;
import java.util.stream.Collectors;

public class TaskTwo {
    Map<Integer, Student> studentsMap= new HashMap<>();
    private int studentId = 1;

    public void addStudent(Student student) {
        studentsMap.put(studentId++, student);
    }

    public void removeStudent(Student student) {
        for (var std: studentsMap.entrySet()) {
            if (std.getValue().equals(student)) {
                System.out.println(std.getValue());
                studentsMap.remove(std.getKey());
            }
        }
    }

    public void searchStudent(Student student) {
        for (var std: studentsMap.entrySet()) {
            if (std.getValue().equals(student)) {
                System.out.println(std.getValue());
            }
        }
    }

    public List<Student> getTopStudents() {
        return studentsMap.values().stream()
                .sorted(Comparator.comparing((Student s) -> Collections.max(s.getGradesList())).reversed())
                .limit(3)
                .collect(Collectors.toList());
    }
}
