package org.example.num;

import java.util.Random;
import java.util.Scanner;

public class NumGenerator {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter value for 'a': ");
        int a = scanner.nextInt();
        System.out.println("Enter value for 'b': ");
        int b = scanner.nextInt();

        if(a > b){
            int temp = a;
            a = b;
            b = temp;
        }

        Random random = new Random();
        int countOfEvenNumbers = 0;
        int sumOfEvenNumbers = 0;
        for (int i = 0; i < 10; i++){
            int randomIntBetweenAAndB = random.nextInt(a, b);
            if (randomIntBetweenAAndB % 2 == 0){
                countOfEvenNumbers++;
                sumOfEvenNumbers += randomIntBetweenAAndB;
            }
        }

        System.out.printf("Count Of Even Numbers: %d \n", countOfEvenNumbers);
        System.out.printf("Sum Of Even Numbers: %d \n", sumOfEvenNumbers);
    }
}
