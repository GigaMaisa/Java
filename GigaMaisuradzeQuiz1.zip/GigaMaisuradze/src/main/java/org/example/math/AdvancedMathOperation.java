package org.example.math;

import java.util.Scanner;

public abstract class AdvancedMathOperation {
    private int z;

    public void setValueForZ(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter value for 'Z': ");
        this.z = scanner.nextInt();
    }

    public abstract int calculateOperation();

    public int getZ() {
        return z;
    }

    public void setZ(int z) {
        this.z = z;
    }
}
