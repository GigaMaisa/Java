package org.example.math;

import java.util.Random;
import java.util.Scanner;

public class MathOperation extends AdvancedMathOperation {
    private int x;
    private int y;

    public MathOperation() {
        System.out.println("Hello");
    }

    public void setFieldValues() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter value for 'X': ");
        this.x = scanner.nextInt();

        System.out.print("Enter value for 'Y': ");
        this.y = scanner.nextInt();
    }

    public void sumWithRandomNumber(){
        Random random = new Random();
        int randomInt = random.nextInt();

        System.out.printf("Result: %d \n", this.x + randomInt);
    }

    public void checkIsEven(){
        int sumOfFields = this.x + this.y;

        if (sumOfFields % 2 == 0) {
            System.out.println("Even");
        } else  {
            System.out.println("Odd");
        }
    }

    @Override
    public int calculateOperation() {
        return (this.x + this.y) * getZ();
    }
}
