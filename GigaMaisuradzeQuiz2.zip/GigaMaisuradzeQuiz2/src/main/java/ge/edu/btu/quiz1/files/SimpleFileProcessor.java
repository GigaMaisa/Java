package ge.edu.btu.quiz1.files;

import ge.edu.btu.quiz1.exceptions.FileCopyException;
import ge.edu.btu.quiz1.exceptions.FileDeletionException;
import java.io.*;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class SimpleFileProcessor implements FileProcessor {
    private static final Logger LOGGER = Logger.getLogger(SimpleFileProcessor.class.getName());

    public SimpleFileProcessor() {
        try {
            FileHandler fileHandler = new FileHandler("file_processing_log.txt", true);
            fileHandler.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(fileHandler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void copyFile(String sourceFileName, String destinationFileName) throws FileCopyException {
        try (InputStream in = new FileInputStream(sourceFileName);
             OutputStream out = new FileOutputStream(destinationFileName)) {
            byte[] buffer = new byte[1024];
            int length;

            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }

            LOGGER.log(Level.INFO, String.format("File copied from %s to %s", sourceFileName, destinationFileName));
        } catch (IOException e) {
            File destinationFile = new File(destinationFileName);
            if (destinationFile.exists()) {
                LOGGER.log(Level.INFO, "Destination file created successfully.");
            } else {
                LOGGER.log(Level.WARNING, "Destination file was not created.");
                throw new FileCopyException("Exception Occured");
            }
            throw new FileCopyException("Exception Occured");
        }
    }

    @Override
    public void deleteFile(String fileName) throws FileDeletionException {
        File file = new File(fileName);
        if (file.exists()) {
            if (file.delete()) {
                LOGGER.log(Level.INFO, String.format("File deleted: %s",fileName));
            } else {
                LOGGER.log(Level.WARNING, String.format("Unable to delete file: %s", fileName), fileName);
                throw new FileDeletionException("Unable to delete file: " + fileName, null);
            }
        } else {
            LOGGER.log(Level.WARNING, "File does not exist: {0}", fileName);
            throw new FileDeletionException("File does not exist: " + fileName, null);
        }
    }
}
