package ge.edu.btu.quiz1.calculator;

import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class SimpleCalculator implements Calculator {
    private static final Logger LOGGER = Logger.getLogger(SimpleCalculator.class.getName());

    public SimpleCalculator() {
        try {
            FileHandler fileHandler = new FileHandler("calculator.txt", true);
            fileHandler.setFormatter(new SimpleFormatter());
            LOGGER.addHandler(fileHandler);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int add(int a, int b) throws ArithmeticException {
        try {
            LOGGER.log(Level.INFO, String.format("Adding %d and %d", a, b));
            int result = a + b;

            LOGGER.log(Level.INFO, String.format("Result is %d", result));
            return result;
        } catch (ArithmeticException e) {
            LOGGER.log(Level.WARNING, "Error occurred while adding", e);
        }
        return 0;
    }

    @Override
    public int subtract(int a, int b) throws ArithmeticException {
        try {
            LOGGER.log(Level.INFO, String.format("Subtracting %d and %d", a, b));
            int result = a - b;

            LOGGER.log(Level.INFO, String.format("Result is %d", result));
            return result;
        } catch (ArithmeticException e) {
            LOGGER.log(Level.WARNING, "Error occurred while subtracting", e);
        }
        return 0;
    }

    @Override
    public int multiply(int a, int b) throws ArithmeticException {
        try {
            LOGGER.log(Level.INFO, String.format("Multiplying %d and %d", a, b));
            int result = a * b;

            LOGGER.log(Level.INFO, String.format("Result is %d", result));
            return result;
        } catch (ArithmeticException e) {
            LOGGER.log(Level.WARNING, "Error occurred while multiplying", e);
        }
        return 0;
    }

    @Override
    public int divide(int a, int b) throws ArithmeticException {
        try {
            LOGGER.log(Level.INFO, String.format("Dividing %d and %d", a, b));
            int result = a / b;

            LOGGER.log(Level.INFO, String.format("Result is %d", result));
            return result;
        } catch (ArithmeticException e) {
            LOGGER.log(Level.WARNING, "Error occurred while dividing", e);
        }
        return 0;
    }
}
