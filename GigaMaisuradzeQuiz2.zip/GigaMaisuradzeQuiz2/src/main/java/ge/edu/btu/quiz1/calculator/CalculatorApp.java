package ge.edu.btu.quiz1.calculator;

public class CalculatorApp {
    public static void main(String[] args) {
        SimpleCalculator simpleCalculator = new SimpleCalculator();
        for (int i = 0; i < 10; i++) {
            simpleCalculator.divide(100, i);
        }
    }
}
