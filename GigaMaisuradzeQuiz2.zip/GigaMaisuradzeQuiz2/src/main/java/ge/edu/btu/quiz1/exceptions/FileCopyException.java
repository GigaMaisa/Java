package ge.edu.btu.quiz1.exceptions;

import java.io.IOException;

public class FileCopyException extends Exception {
    public FileCopyException(String message) {
        super(message);
    }
}
