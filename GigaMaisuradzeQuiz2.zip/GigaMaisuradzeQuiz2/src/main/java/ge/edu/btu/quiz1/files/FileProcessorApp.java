package ge.edu.btu.quiz1.files;

import ge.edu.btu.quiz1.exceptions.FileCopyException;
import ge.edu.btu.quiz1.exceptions.FileDeletionException;

public class FileProcessorApp {
    public static void main(String[] args)  {
        SimpleFileProcessor simpleFileProcessor = new SimpleFileProcessor();
        try {
            simpleFileProcessor.copyFile("calculatorr.txt", "new_calculator.txt");
        } catch (FileCopyException e) {
            e.printStackTrace();
        }

//        simpleFileProcessor.deleteFile("new_calculator.txt");
    }
}
