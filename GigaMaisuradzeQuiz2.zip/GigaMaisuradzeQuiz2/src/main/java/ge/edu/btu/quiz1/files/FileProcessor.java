package ge.edu.btu.quiz1.files;

import ge.edu.btu.quiz1.exceptions.FileCopyException;
import ge.edu.btu.quiz1.exceptions.FileDeletionException;

public interface FileProcessor {
    void copyFile(String sourceFileName, String destinationFileName) throws FileCopyException;
    void deleteFile(String fileName) throws FileDeletionException;
}
