package ge.edu.btu.quiz1.exceptions;

import java.io.FileNotFoundException;
import java.io.IOException;

public class FileDeletionException extends Exception {
    public FileDeletionException(String message, Throwable cause) {
        super(message, cause);
    }
}


