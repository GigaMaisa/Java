package ge.edu.btu.quiz4.task2;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        DaysOfWeek today = DaysOfWeek.THURSDAY;
        displayDayInfo(today);

        System.out.println("\nDays of the week:");
        for (DaysOfWeek day : DaysOfWeek.values()) {
            System.out.println(day);
        }

        System.out.println("Shemdgomi dge aris " + today.getNextDay());
        System.out.println("Wina dge gaxlavt  " + today.getPreviousDay());

        System.out.println("\n" + today + " samushao dgea smn to??? " + today.isWeekday());
        System.out.println(today + " dalevis dge aris tu ara: " + today.isWeekend());

        List<DaysOfWeek> days = new ArrayList<>();
        days.add(DaysOfWeek.MONDAY);
        days.add(DaysOfWeek.TUESDAY);
        days.add(DaysOfWeek.WEDNESDAY);
        days.add(DaysOfWeek.THURSDAY);
        days.add(DaysOfWeek.FRIDAY);
        days.add(DaysOfWeek.SATURDAY);
        days.add(DaysOfWeek.SUNDAY);

        System.out.println("\nWeekdays:");
        displayFilteredDays(days, true);

        System.out.println("\nWeekends:");
        displayFilteredDays(days, false);
    }

    private static void displayDayInfo(DaysOfWeek day) {
        switch (day) {
            case MONDAY -> System.out.println("shit....");
            case THURSDAY -> System.out.println("goood");
            case FRIDAY -> System.out.println("YAAAAAAAAAAAY");
            default -> System.out.println("eh ");
        }
    }

    public static void displayFilteredDays(List<DaysOfWeek> daysList, boolean isWeekday) {
        for (DaysOfWeek day : daysList) {
            if (isWeekday && day.isWeekday()) {
                System.out.println(day);
            } else if (!isWeekday && day.isWeekend()) {
                System.out.println(day);
            }
        }
    }
}
