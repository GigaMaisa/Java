package ge.edu.btu.quiz4.task2;

enum DaysOfWeek {
    MONDAY("Mon", 1),
    TUESDAY("Tue", 2),
    WEDNESDAY("Wed", 3),
    THURSDAY("Thu", 4),
    FRIDAY("Fri", 5),
    SATURDAY("Sat", 6),
    SUNDAY("Sun", 7);

    private final String shortName;
    private final int dayNumber;

    DaysOfWeek(String shortName, int dayNumber) {
        this.shortName = shortName;
        this.dayNumber = dayNumber;
    }

    @SuppressWarnings("unused")
    public String getShortName() {
        return shortName;
    }

    @SuppressWarnings("unused")
    public int getDayNumber() {
        return dayNumber;
    }

    public DaysOfWeek getNextDay() {
        int nextOrdinal = (this.ordinal() + 1) % DaysOfWeek.values().length;
        return DaysOfWeek.values()[nextOrdinal];
    }

    public DaysOfWeek getPreviousDay() {
        int prevOrdinal = (this.ordinal() - 1 + DaysOfWeek.values().length) % DaysOfWeek.values().length;
        return DaysOfWeek.values()[prevOrdinal];
    }

    public boolean isWeekday() {
        return this.dayNumber >= MONDAY.dayNumber && this.dayNumber <= FRIDAY.dayNumber;
    }

    public boolean isWeekend() {
        return this.dayNumber == SATURDAY.dayNumber || this.dayNumber == SUNDAY.dayNumber;
    }

    @Override
    public String toString() {
        return this.name() + "(" + this.shortName + ", " + this.dayNumber + ")";
    }
}

