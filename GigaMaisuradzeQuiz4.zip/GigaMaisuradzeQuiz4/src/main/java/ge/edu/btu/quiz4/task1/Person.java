package ge.edu.btu.quiz4.task1;

import java.io.Serial;
import java.io.Serializable;
import java.util.List;

record Person(String name, String lastName, int age, List<Task> tasks) implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
}
