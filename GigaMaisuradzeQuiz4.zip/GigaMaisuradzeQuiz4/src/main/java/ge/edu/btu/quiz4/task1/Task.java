package ge.edu.btu.quiz4.task1;

import java.io.Serializable;

class Task implements Serializable {
    private static final long serialVersionUID = 1L;
    private String description;

    public Task(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "Task{" +
                "description='" + description + '\'' +
                '}';
    }
}