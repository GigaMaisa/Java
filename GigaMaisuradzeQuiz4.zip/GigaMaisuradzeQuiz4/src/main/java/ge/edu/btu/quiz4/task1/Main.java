package ge.edu.btu.quiz4.task1;

import java.io.IOException;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        Task task1 = new Task("android");
        Task task2 = new Task("kotlin");

        List<Task> tasks = List.of(task1, task2);

        Person person = new Person("Zezva", "Shavyverashvili", 21, tasks);
        List<Person> persons = List.of(person);

        String fileName = "nibba.txt";

        try {
            SerializationUtil.serialize(persons, fileName);
            List<Person> deserializedPersons = SerializationUtil.deserialize(fileName);
            deserializedPersons.forEach(System.out::println);
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

}

